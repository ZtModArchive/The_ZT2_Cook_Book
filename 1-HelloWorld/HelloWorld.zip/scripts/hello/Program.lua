include "scenario/scripts/misc.lua"

function Greeting (args)
    local animal = resolveTable(args[1].value)
    local name = animal:BFG_GET_ATTR_STRING("s_name")
    displayZooMessageTextWithZoom("Hello "..name, 1, 30, animal)
end